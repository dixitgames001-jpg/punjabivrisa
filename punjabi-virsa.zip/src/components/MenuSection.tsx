import { useState, useMemo } from 'react';
import { Search, Flame, Sparkles, Check, Plus, Minus, Info } from 'lucide-react';
import { MenuItem } from '../types';
import { MENU_ITEMS } from '../data';

interface MenuSectionProps {
  onAddToBookingDraft: (item: MenuItem) => void;
  onRemoveFromBookingDraft: (item: MenuItem) => void;
  bookingDraft: { [key: string]: number };
}

export default function MenuSection({
  onAddToBookingDraft,
  onRemoveFromBookingDraft,
  bookingDraft,
}: MenuSectionProps) {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showVegOnly, setShowVegOnly] = useState<boolean>(false);

  const categories = [
    { label: 'All Dishes', id: 'all' },
    { label: 'Starters', id: 'starters' },
    { label: 'Main Course', id: 'main_course' },
    { label: 'Breads', id: 'breads' },
    { label: 'Rice', id: 'rice' },
    { label: 'Desserts', id: 'desserts' },
    { label: 'Drinks', id: 'drinks' },
  ];

  // Filter items based on Category, Search query, and Veg Only
  const filteredItems = useMemo(() => {
    return MENU_ITEMS.filter((item) => {
      // Category filter
      if (activeCategory !== 'all' && item.category !== activeCategory) {
        return false;
      }
      // Veg only filter
      if (showVegOnly && !item.isVeg) {
        return false;
      }
      // Search query filter
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc) {
          return false;
        }
      }
      return true;
    });
  }, [activeCategory, searchQuery, showVegOnly]);

  const draftCountTotal = useMemo(() => {
    return Object.values(bookingDraft).reduce((sum, count) => sum + count, 0);
  }, [bookingDraft]);

  return (
    <section id="menu" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold tracking-widest text-brand-600 uppercase">The Culinary Gallery</span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 mt-2 mb-4">
            Our Traditional Menu
          </h2>
          <p className="text-stone-600 text-sm sm:text-base">
            Explore authentic flavors of Punjab, hand-prepared daily with carefully ground spices and fresh, premium ingredients.
          </p>
        </div>

        {/* Filters and Controls */}
        <div className="bg-brand-50/60 border border-stone-200/60 rounded-3xl p-6 mb-10 shadow-sm flex flex-col space-y-4 md:space-y-0 md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Search bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search dishes (e.g. Butter Chicken, Naan)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white text-stone-800 text-sm pl-12 pr-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all shadow-sm"
            />
          </div>

          {/* Vegetarian Toggle & Draft Badge */}
          <div className="flex flex-wrap items-center gap-6">
            
            {/* Indian standard Vegetarian switch */}
            <label className="inline-flex items-center cursor-pointer select-none">
              <input
                type="checkbox"
                checked={showVegOnly}
                onChange={() => setShowVegOnly(!showVegOnly)}
                className="sr-only peer"
              />
              <div className="relative w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
              <span className="ml-3 text-sm font-semibold text-stone-700 flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 bg-emerald-600 border border-white rounded-full inline-block" />
                <span>Veg Only</span>
              </span>
            </label>

            {/* Notification if some items are selected for booking */}
            {draftCountTotal > 0 && (
              <div className="bg-amber-100 text-brand-800 border border-amber-200 px-4 py-1.5 rounded-full text-xs font-semibold flex items-center space-x-2 animate-pulse">
                <Sparkles className="w-4.5 h-4.5 text-amber-500" />
                <span>{draftCountTotal} items added to booking draft</span>
              </div>
            )}
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex overflow-x-auto pb-4 mb-10 -mx-4 px-4 scrollbar-thin scrollbar-thumb-amber-500 scrollbar-track-stone-100 lg:-mx-0 lg:px-0">
          <div className="flex space-x-1.5 bg-stone-100 p-1.5 rounded-2xl border border-stone-200/60 mx-auto">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-amber-500 text-stone-950 font-semibold shadow-sm'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Menu Cards Grid */}
        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item) => {
              const countInDraft = bookingDraft[item.id] || 0;
              return (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl overflow-hidden border border-stone-100 hover:border-amber-200 shadow-sm hover:shadow-lg transition-all flex flex-col group h-full"
                >
                  {/* Card Image */}
                  <div className="relative h-48 overflow-hidden bg-stone-100">
                    <img
                      src={item.image}
                      alt={item.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    
                    {/* Dark gradient overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60" />

                    {/* Veg / Non-veg symbol indicator inside card */}
                    <div className="absolute top-4 left-4 z-10 bg-white/95 backdrop-blur-sm p-1.5 rounded-lg shadow-sm">
                      <div className={`w-4 h-4 border-2 flex items-center justify-center p-0.5 ${item.isVeg ? 'border-emerald-600' : 'border-rose-600'}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${item.isVeg ? 'bg-emerald-600' : 'bg-rose-600'}`} />
                      </div>
                    </div>

                    {/* Badges */}
                    <div className="absolute top-4 right-4 flex flex-col space-y-2 items-end">
                      {item.isPopular && (
                        <span className="bg-amber-500 text-stone-950 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider shadow-sm flex items-center space-x-1">
                          <Sparkles className="w-3 h-3 fill-current" />
                          <span>Chef's Special</span>
                        </span>
                      )}
                      <span className="bg-stone-950/80 backdrop-blur-sm text-amber-400 text-xs font-semibold px-2.5 py-1 rounded-lg">
                        ₹{item.price}
                      </span>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Name & Spicy indicator */}
                      <div className="flex items-start justify-between mb-2 gap-2">
                        <h3 className="font-serif font-bold text-stone-900 text-lg group-hover:text-amber-700 transition-colors">
                          {item.name}
                        </h3>
                        {item.spicyLevel !== undefined && item.spicyLevel > 0 && (
                          <div className="flex items-center text-amber-600 space-x-0.5" title={`${item.spicyLevel}/3 Spicy Level`}>
                            {Array.from({ length: item.spicyLevel }).map((_, i) => (
                              <Flame key={i} className="w-4 h-4 fill-current text-rose-600" />
                            ))}
                          </div>
                        )}
                      </div>

                      <p className="text-stone-600 text-xs sm:text-sm leading-relaxed mb-6">
                        {item.description}
                      </p>
                    </div>

                    {/* Footer buttons / Reservation draft controls */}
                    <div className="pt-4 border-t border-stone-100 flex items-center justify-between">
                      <span className="text-xs text-stone-500 font-medium">Add to Table Reservation:</span>
                      
                      {countInDraft > 0 ? (
                        <div className="flex items-center space-x-2 bg-amber-500 text-stone-950 rounded-xl px-2.5 py-1 shadow-sm font-semibold text-sm">
                          <button
                            onClick={() => onRemoveFromBookingDraft(item)}
                            className="p-1 hover:bg-amber-600/50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-1 text-xs">{countInDraft}</span>
                          <button
                            onClick={() => onAddToBookingDraft(item)}
                            className="p-1 hover:bg-amber-600/50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => onAddToBookingDraft(item)}
                          className="border border-amber-500 text-amber-700 hover:bg-amber-500 hover:text-stone-950 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center space-x-1 transition-all cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16 bg-brand-50 rounded-3xl border border-dashed border-stone-300 max-w-lg mx-auto">
            <Info className="w-12 h-12 text-stone-400 mx-auto mb-4" />
            <h4 className="font-serif font-bold text-stone-800 text-lg mb-1">No Dishes Found</h4>
            <p className="text-stone-500 text-sm px-6">
              We couldn't find any menu items matching your search. Try resetting your filters or adjusting your keywords.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setActiveCategory('all');
                setShowVegOnly(false);
              }}
              className="mt-6 text-xs font-bold text-amber-700 underline hover:text-amber-900 cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
