import { useState } from 'react';
import { X, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react';
import { GALLERY_IMAGES } from '../data';

export default function Gallery() {
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);

  const openLightbox = (index: number) => {
    setLightboxIdx(index);
  };

  const closeLightbox = () => {
    setLightboxIdx(null);
  };

  const navigateLightbox = (direction: 'prev' | 'next') => {
    if (lightboxIdx === null) return;
    
    let nextIdx = lightboxIdx;
    if (direction === 'prev') {
      nextIdx = lightboxIdx === 0 ? GALLERY_IMAGES.length - 1 : lightboxIdx - 1;
    } else {
      nextIdx = lightboxIdx === GALLERY_IMAGES.length - 1 ? 0 : lightboxIdx + 1;
    }
    setLightboxIdx(nextIdx);
  };

  return (
    <section id="gallery" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-widest text-brand-600 uppercase">Visual Journey</span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 mt-2 mb-4">
            Gallery of Delights
          </h2>
          <p className="text-stone-600 text-sm sm:text-base">
            Take a visual tour of our culinary craftsmanship. Browse through freshly baked naans, steaming gravies, and delicious desserts.
          </p>
        </div>

        {/* Photo Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {GALLERY_IMAGES.map((img, index) => (
            <div
              key={index}
              onClick={() => openLightbox(index)}
              className="group relative h-72 sm:h-80 rounded-2xl overflow-hidden shadow-sm hover:shadow-md cursor-pointer border border-stone-100"
            >
              {/* Image */}
              <img
                src={img.url}
                alt={img.caption}
                loading="lazy"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              
              {/* Semi-transparent dark overlay */}
              <div className="absolute inset-0 bg-stone-950/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-6" />

              {/* Hover effect overlays */}
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-full opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300 shadow-md">
                <ZoomIn className="w-5 h-5 text-stone-800" />
              </div>

              <div className="absolute bottom-6 left-6 right-6 opacity-0 group-hover:opacity-100 translate-y-3 group-hover:translate-y-0 transition-all duration-300">
                <p className="text-white font-serif font-bold text-lg mb-0.5 leading-tight">
                  {img.caption}
                </p>
                <p className="text-amber-400 text-xs uppercase tracking-widest font-semibold">
                  Punjabi Virsa Authentic
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Full-Screen Lightbox Overlay */}
      {lightboxIdx !== null && (
        <div className="fixed inset-0 z-50 bg-stone-950/98 flex flex-col justify-between py-6 px-4">
          
          {/* Header Bar */}
          <div className="flex items-center justify-between max-w-7xl mx-auto w-full text-white">
            <span className="text-stone-400 text-sm font-medium">
              Image {lightboxIdx + 1} of {GALLERY_IMAGES.length}
            </span>
            <button
              onClick={closeLightbox}
              className="p-2 hover:bg-stone-800 rounded-full transition-colors text-white cursor-pointer"
              title="Close Gallery Lightbox"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Main Showcase Stage */}
          <div className="relative flex items-center justify-center flex-1 max-w-7xl mx-auto w-full select-none">
            
            {/* Left Nav Button */}
            <button
              onClick={() => navigateLightbox('prev')}
              className="absolute left-0 sm:left-4 z-10 bg-stone-900/80 hover:bg-stone-800 border border-stone-800 text-white p-3 rounded-full transition-colors cursor-pointer"
              title="Previous Image"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Showcase Image */}
            <div className="max-h-[70vh] max-w-full flex items-center justify-center">
              <img
                src={GALLERY_IMAGES[lightboxIdx].url}
                alt={GALLERY_IMAGES[lightboxIdx].caption}
                className="max-h-[70vh] max-w-full object-contain rounded-lg shadow-2xl animate-fade-in"
              />
            </div>

            {/* Right Nav Button */}
            <button
              onClick={() => navigateLightbox('next')}
              className="absolute right-0 sm:right-4 z-10 bg-stone-900/80 hover:bg-stone-800 border border-stone-800 text-white p-3 rounded-full transition-colors cursor-pointer"
              title="Next Image"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Caption Bar */}
          <div className="text-center max-w-3xl mx-auto w-full text-white pb-4">
            <h4 className="font-serif font-bold text-xl text-amber-400 mb-1">
              {GALLERY_IMAGES[lightboxIdx].caption}
            </h4>
            <p className="text-stone-400 text-xs uppercase tracking-widest font-semibold">
              Punjabi Virsa Authentic Kitchen
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
