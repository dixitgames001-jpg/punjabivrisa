import React, { useState } from 'react';
import { Phone, MapPin, Mail, Clock, Send, CheckCircle, Navigation, Copy } from 'lucide-react';
import { RESTAURANT_INFO } from '../data';

export default function Contact() {
  const [senderName, setSenderName] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  const [senderSubject, setSenderSubject] = useState('');
  const [senderMessage, setSenderMessage] = useState('');
  const [copiedSuccess, setCopiedSuccess] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(RESTAURANT_INFO.address).then(() => {
      setCopiedSuccess(true);
      setTimeout(() => setCopiedSuccess(false), 2500);
    });
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!senderName.trim() || !senderEmail.trim() || !senderMessage.trim()) return;

    // Simulate messaging submission
    setFormSubmitted(true);
    setSenderName('');
    setSenderEmail('');
    setSenderSubject('');
    setSenderMessage('');

    setTimeout(() => {
      setFormSubmitted(false);
    }, 5000);
  };

  return (
    <section id="contact" className="py-24 bg-brand-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-widest text-brand-600 uppercase">Connect With Us</span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 mt-2 mb-4">
            Contact & Location
          </h2>
          <p className="text-stone-600 text-sm sm:text-base">
            Reach out for party enquiries, home takeaways, bulk event catering, or drop by to savor our authentic clay-oven delicacies.
          </p>
        </div>

        {/* Contact info grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Contact Cards & Hours */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Quick Phone Card */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200/60 shadow-sm flex items-start space-x-4">
              <div className="bg-amber-500/10 text-brand-600 p-3 rounded-xl shrink-0">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-base mb-1">Call Us</h4>
                <a
                  href={`tel:${RESTAURANT_INFO.phone}`}
                  className="text-stone-600 text-sm hover:text-amber-700 transition-colors block font-semibold"
                >
                  {RESTAURANT_INFO.phone}
                </a>
                <span className="text-[10px] text-stone-400 block mt-1">Accepting phone bookings & takeaways</span>
              </div>
            </div>

            {/* Quick Email Card */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200/60 shadow-sm flex items-start space-x-4">
              <div className="bg-amber-500/10 text-brand-600 p-3 rounded-xl shrink-0">
                <Mail className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-base mb-1">Email Support</h4>
                <a
                  href={`mailto:${RESTAURANT_INFO.email}`}
                  className="text-stone-600 text-sm hover:text-amber-700 transition-colors block font-semibold"
                >
                  {RESTAURANT_INFO.email}
                </a>
                <span className="text-[10px] text-stone-400 block mt-1">Catering, feedback, and job openings</span>
              </div>
            </div>

            {/* Opening Hours Card */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200/60 shadow-sm flex items-start space-x-4">
              <div className="bg-amber-500/10 text-brand-600 p-3 rounded-xl shrink-0">
                <Clock className="w-6 h-6" />
              </div>
              <div className="w-full">
                <h4 className="font-serif font-bold text-stone-900 text-base mb-1">Opening Hours</h4>
                <div className="flex justify-between text-stone-600 text-xs sm:text-sm font-semibold pt-1 border-b border-stone-100 pb-1.5">
                  <span>Monday – Sunday</span>
                  <span>12:00 PM – 12:00 AM</span>
                </div>
                <span className="text-[10px] text-stone-400 block mt-1.5">Serving hot lunch, dinner, and late-night snacks</span>
              </div>
            </div>
          </div>

          {/* Contact Message Form */}
          <div className="lg:col-span-4 bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/60 shadow-sm">
            <h3 className="font-serif text-lg sm:text-xl font-bold text-stone-900 mb-2">Send Us a Message</h3>
            <p className="text-stone-500 text-xs sm:text-sm mb-6">Have any queries or comments? Fill in the details below.</p>

            {formSubmitted && (
              <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 p-4 rounded-xl mb-6 text-xs flex items-start space-x-2 animate-fade-in">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <span className="font-bold block mb-0.5">Message Sent!</span>
                  <span>Thank you. Our executive team will reply via email shortly.</span>
                </div>
              </div>
            )}

            <form onSubmit={handleContactSubmit} className="space-y-4">
              <div>
                <label htmlFor="conName" className="block text-stone-700 text-[10px] font-bold uppercase tracking-wider mb-1.5">Name</label>
                <input
                  type="text"
                  id="conName"
                  required
                  placeholder="Your Name"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                />
              </div>

              <div>
                <label htmlFor="conEmail" className="block text-stone-700 text-[10px] font-bold uppercase tracking-wider mb-1.5">Email</label>
                <input
                  type="email"
                  id="conEmail"
                  required
                  placeholder="Your Email"
                  value={senderEmail}
                  onChange={(e) => setSenderEmail(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                />
              </div>

              <div>
                <label htmlFor="conSubject" className="block text-stone-700 text-[10px] font-bold uppercase tracking-wider mb-1.5">Subject</label>
                <input
                  type="text"
                  id="conSubject"
                  placeholder="e.g. Catering for 50 people"
                  value={senderSubject}
                  onChange={(e) => setSenderSubject(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                />
              </div>

              <div>
                <label htmlFor="conMsg" className="block text-stone-700 text-[10px] font-bold uppercase tracking-wider mb-1.5">Message</label>
                <textarea
                  id="conMsg"
                  rows={3}
                  required
                  placeholder="Type your message here..."
                  value={senderMessage}
                  onChange={(e) => setSenderMessage(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-stone-900 hover:bg-stone-800 text-white font-bold py-3 rounded-xl text-xs sm:text-sm transition-all shadow-md active:scale-95 flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Send className="w-4 h-4 text-amber-400" />
                <span>Send Message</span>
              </button>
            </form>
          </div>

          {/* Styled Geographic Map Card */}
          <div className="lg:col-span-4 bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/60 shadow-sm flex flex-col justify-between h-full min-h-[460px]">
            <div>
              <div className="flex items-center space-x-2 pb-4 border-b border-stone-100 mb-6">
                <MapPin className="w-5 h-5 text-amber-500 shrink-0" />
                <h3 className="font-serif text-lg sm:text-xl font-bold text-stone-900">How to Find Us</h3>
              </div>
              
              {/* Styled Address Section */}
              <p className="text-stone-700 text-sm leading-relaxed mb-6 font-semibold">
                {RESTAURANT_INFO.address}
              </p>

              {/* Landmark points */}
              <div className="space-y-3 mb-6 text-xs sm:text-sm text-stone-500">
                <div className="flex items-start space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0 mt-1.5" />
                  <span>Located near SHYAM NAGAR METRO STATION (approx. 5 min drive).</span>
                </div>
                <div className="flex items-start space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0 mt-1.5" />
                  <span>Ample roadside valet parking available.</span>
                </div>
              </div>
            </div>

            {/* Custom stylized vector Map simulation */}
            <div className="bg-brand-50 border border-stone-200 rounded-2xl p-4 flex-1 flex flex-col justify-between text-center relative overflow-hidden group mb-6 min-h-[180px]">
              {/* Styled Abstract Map Graphic lines representing streets */}
              <div className="absolute inset-0 opacity-15 pointer-events-none select-none">
                <div className="absolute top-1/4 left-0 right-0 h-[2px] bg-stone-900 rotate-[5deg]" />
                <div className="absolute top-1/2 left-0 right-0 h-[2px] bg-stone-900 rotate-[-10deg]" />
                <div className="absolute bottom-1/4 left-0 right-0 h-[3px] bg-stone-900 rotate-[15deg]" />
                <div className="absolute left-1/3 top-0 bottom-0 w-[2px] bg-stone-900 rotate-[25deg]" />
                <div className="absolute left-2/3 top-0 bottom-0 w-[2px] bg-stone-900 rotate-[-30deg]" />
              </div>

              {/* Map pin beacon */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center">
                <div className="w-3 h-3 bg-brand-500 rounded-full animate-ping absolute" />
                <MapPin className="w-8 h-8 text-brand-600 fill-amber-100 drop-shadow-md relative" />
                <span className="bg-stone-950 text-white text-[9px] font-bold px-2 py-0.5 rounded shadow mt-1 whitespace-nowrap">
                  PUNJABI VIRSA
                </span>
              </div>

              <span className="text-[10px] text-stone-400 font-bold uppercase tracking-wider relative z-20 self-start block">SHYAM NAGAR ROAD MAP</span>
              <span className="text-[11px] text-stone-500 font-medium relative z-20 self-end block">Vishnu Garden, New Delhi</span>
            </div>

            {/* Action buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleCopyAddress}
                className={`border border-stone-300 font-semibold py-2.5 rounded-xl text-xs transition-all flex items-center justify-center space-x-1 cursor-pointer ${
                  copiedSuccess ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : 'text-stone-700 hover:bg-stone-50'
                }`}
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copiedSuccess ? 'Address Copied!' : 'Copy Address'}</span>
              </button>
              
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(RESTAURANT_INFO.address)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-stone-900 hover:bg-stone-800 text-white font-semibold py-2.5 rounded-xl text-xs transition-all flex items-center justify-center space-x-1 shadow"
              >
                <Navigation className="w-3.5 h-3.5 text-amber-400" />
                <span>Get Directions</span>
              </a>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
