import { useState, useEffect } from 'react';
import { MenuItem } from './types';

// Component Imports
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import MenuSection from './components/MenuSection';
import SpecialOffers from './components/SpecialOffers';
import Gallery from './components/Gallery';
import Reviews from './components/Reviews';
import BookingForm from './components/BookingForm';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('home');
  
  // State to hold menu item quantities selected for the table reservation draft
  // Mapping of menuItemId -> quantity
  const [bookingDraft, setBookingDraft] = useState<{ [key: string]: number }>({});

  // 1. Scroll-Spy Intersection Observer to update active section in Navbar
  useEffect(() => {
    const sections = ['home', 'about', 'menu', 'offers', 'gallery', 'reviews', 'booking', 'contact'];
    
    const observerOptions = {
      root: null,
      rootMargin: '-30% 0px -60% 0px', // Trigger when section occupies the middle of screen
      threshold: 0,
    };

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);

    sections.forEach((id) => {
      const element = document.getElementById(id);
      if (element) {
        observer.observe(element);
      }
    });

    return () => {
      sections.forEach((id) => {
        const element = document.getElementById(id);
        if (element) {
          observer.unobserve(element);
        }
      });
    };
  }, []);

  // 2. Draft Food Order Handlers
  const handleAddToBookingDraft = (item: MenuItem) => {
    setBookingDraft((prev) => ({
      ...prev,
      [item.id]: (prev[item.id] || 0) + 1,
    }));
  };

  const handleRemoveFromBookingDraft = (item: MenuItem) => {
    setBookingDraft((prev) => {
      const currentCount = prev[item.id] || 0;
      if (currentCount <= 1) {
        const copy = { ...prev };
        delete copy[item.id];
        return copy;
      }
      return {
        ...prev,
        [item.id]: currentCount - 1,
      };
    });
  };

  const handleClearDraft = () => {
    setBookingDraft({});
  };

  // 3. Smooth scrolling handlers
  const handleScrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-brand-50/20 antialiased font-sans">
      
      {/* Sticky & Responsive Header Navbar */}
      <Navbar activeSection={activeSection} setActiveSection={setActiveSection} />

      {/* Main Content Sections */}
      <main className="flex-grow">
        
        {/* Home / Hero landing section */}
        <Hero
          onExploreMenu={() => handleScrollToSection('menu')}
          onBookTable={() => handleScrollToSection('booking')}
        />

        {/* Brand story, rating, and Why Choose Us bento cards */}
        <About />

        {/* Digital filterable menu grid with custom item draft controllers */}
        <MenuSection
          onAddToBookingDraft={handleAddToBookingDraft}
          onRemoveFromBookingDraft={handleRemoveFromBookingDraft}
          bookingDraft={bookingDraft}
        />

        {/* Promos, coupons, and dining package bundles */}
        <SpecialOffers />

        {/* Interactive image grid with lightbox slide view */}
        <Gallery />

        {/* Verified user reviews list and dynamic star feedback form */}
        <Reviews />

        {/* Online table reservation panel + my booking manager list dashboard */}
        <BookingForm
          bookingDraft={bookingDraft}
          onClearDraft={handleClearDraft}
          onRemoveFromBookingDraft={handleRemoveFromBookingDraft}
        />

        {/* Address location details, hours card, and styled landmarks board */}
        <Contact />

      </main>

      {/* High-contrast brand directory & copyright footer */}
      <Footer onNavClick={handleScrollToSection} />

    </div>
  );
}
