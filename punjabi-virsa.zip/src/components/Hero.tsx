import { motion } from 'motion/react';
import { ArrowRight, Star, Award, ShieldCheck, Heart } from 'lucide-react';
import { RESTAURANT_INFO } from '../data';

interface HeroProps {
  onExploreMenu: () => void;
  onBookTable: () => void;
}

export default function Hero({ onExploreMenu, onBookTable }: HeroProps) {
  return (
    <section id="home" className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-stone-950 text-white py-20">
      {/* Background Image with elegant dark gradients overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1585938338990-407c3483222c?auto=format&fit=crop&w=1920&q=80"
          alt="Punjabi spices and clay oven background"
          className="w-full h-full object-cover opacity-35 filter brightness-[0.4]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-900/60 to-stone-950" />
        <div className="absolute inset-y-0 right-0 w-1/3 bg-gradient-to-l from-amber-500/5 to-transparent pointer-events-none" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Top welcome rating pill */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center space-x-2 bg-amber-500/10 border border-amber-500/30 px-4 py-1.5 rounded-full text-amber-400 text-xs sm:text-sm mb-6"
        >
          <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
          <span className="font-semibold">{RESTAURANT_INFO.rating.toFixed(1)}/5 Stars</span>
          <span className="text-amber-500/60">|</span>
          <span>1,800+ Happy Guests</span>
        </motion.div>

        {/* Big Catchy Title */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-serif text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6 max-w-4xl mx-auto leading-tight"
        >
          <span className="text-white">Authentic </span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-200 to-amber-500">
            Punjabi
          </span>
          <span className="text-white"> Flavors,</span>
          <br className="hidden sm:inline" />
          <span className="font-serif italic font-normal text-amber-100">Served with Love.</span>
        </motion.h1>

        {/* Subtitle / Description */}
        <motion.p
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-stone-300 text-base sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed font-sans"
        >
          {RESTAURANT_INFO.description}
        </motion.p>

        {/* Action CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4 mb-16"
        >
          <button
            onClick={onExploreMenu}
            className="w-full sm:w-auto bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-stone-950 font-bold px-8 py-4 rounded-full text-base shadow-lg shadow-amber-500/20 active:scale-95 transition-all flex items-center justify-center space-x-2 group cursor-pointer"
          >
            <span>Explore Our Menu</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
          
          <button
            onClick={onBookTable}
            className="w-full sm:w-auto bg-transparent hover:bg-stone-900 border border-stone-600 hover:border-amber-400 text-stone-200 hover:text-amber-400 font-semibold px-8 py-4 rounded-full text-base active:scale-95 transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <span>Book Table online</span>
          </button>
        </motion.div>

        {/* Features banner / Mini-badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-8 border-t border-stone-800/60 max-w-5xl mx-auto"
        >
          <div className="flex flex-col items-center space-y-2 text-center">
            <div className="bg-amber-500/10 p-3 rounded-full border border-amber-500/20">
              <Award className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-xs sm:text-sm font-semibold text-stone-200">Heritage Recipes</span>
          </div>

          <div className="flex flex-col items-center space-y-2 text-center">
            <div className="bg-amber-500/10 p-3 rounded-full border border-amber-500/20">
              <Heart className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-xs sm:text-sm font-semibold text-stone-200">100% Fresh Food</span>
          </div>

          <div className="flex flex-col items-center space-y-2 text-center">
            <div className="bg-amber-500/10 p-3 rounded-full border border-amber-500/20">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-xs sm:text-sm font-semibold text-stone-200">Hygienic Kitchen</span>
          </div>

          <div className="flex flex-col items-center space-y-2 text-center">
            <div className="bg-amber-500/10 p-3 rounded-full border border-amber-500/20">
              <Star className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-xs sm:text-sm font-semibold text-stone-200">₹200–₹1000 Pricing</span>
          </div>
        </motion.div>
      </div>

      {/* Decorative Wave Bottom Cut */}
      <div className="absolute bottom-0 left-0 right-0 h-8 bg-brand-50 pointer-events-none" />
    </section>
  );
}
