import React, { useState, useEffect, useMemo } from 'react';
import { Calendar, Users, Clock, Utensils, Clipboard, CheckCircle, Trash2, Edit, AlertCircle } from 'lucide-react';
import { Booking, MenuItem } from '../types';
import { RESTAURANT_INFO, MENU_ITEMS } from '../data';

interface BookingFormProps {
  bookingDraft: { [key: string]: number };
  onClearDraft: () => void;
  onRemoveFromBookingDraft: (item: MenuItem) => void;
}

export default function BookingForm({
  bookingDraft,
  onClearDraft,
  onRemoveFromBookingDraft,
}: BookingFormProps) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [guests, setGuests] = useState<number>(4);
  const [specialRequests, setSpecialRequests] = useState('');
  const [validationError, setValidationError] = useState('');
  
  // Confirmed booking state for receipt screen
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);

  // Today's date for input limit
  const todayDateStr = useMemo(() => {
    return new Date().toISOString().split('T')[0];
  }, []);

  // Time Slots
  const timeSlots = [
    '12:00 PM', '12:30 PM', '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM',
    '7:00 PM', '7:30 PM', '8:00 PM', '8:30 PM', '9:00 PM', '9:30 PM', '10:00 PM', '10:30 PM', '11:00 PM'
  ];

  // Load bookings from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('punjabi_virsa_bookings');
    if (stored) {
      try {
        setBookings(JSON.parse(stored));
      } catch (e) {
        setBookings([]);
      }
    }
  }, []);

  // Compute draft item details for display
  const draftItemsDetails = useMemo(() => {
    const details: { item: MenuItem; count: number }[] = [];
    Object.entries(bookingDraft).forEach(([id, count]) => {
      if (count > 0) {
        const found = MENU_ITEMS.find((m) => m.id === id);
        if (found) {
          details.push({ item: found, count });
        }
      }
    });
    return details;
  }, [bookingDraft]);

  const draftTotalPrice = useMemo(() => {
    return draftItemsDetails.reduce((sum, d) => sum + d.item.price * d.count, 0);
  }, [draftItemsDetails]);

  // Handle Form Submission
  const handleBookTable = (e: React.FormEvent) => {
    e.preventDefault();

    // Validations
    if (!name.trim()) return setValidationError('Please enter your full name.');
    if (!email.trim() || !email.includes('@')) return setValidationError('Please enter a valid email address.');
    if (!phone.trim() || phone.trim().length < 8) return setValidationError('Please enter a valid phone number.');
    if (!date) return setValidationError('Please select a dining date.');
    if (!time) return setValidationError('Please select a preferred time slot.');

    // Build the request message from food draft
    let foodRequests = '';
    if (draftItemsDetails.length > 0) {
      foodRequests = ` [Food Order Pre-selected: ${draftItemsDetails.map((d) => `${d.item.name} (x${d.count})`).join(', ')}]`;
    }

    const newBooking: Booking = {
      id: `PV-${Math.floor(100000 + Math.random() * 900000)}`,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      date,
      time,
      guests,
      specialRequests: (specialRequests + foodRequests).trim(),
      status: 'confirmed', // Immediate mock confirmation
      tableNumber: Math.floor(1 + Math.random() * 24),
      createdAt: new Date().toISOString(),
    };

    const updatedBookings = [...bookings, newBooking];
    setBookings(updatedBookings);
    localStorage.setItem('punjabi_virsa_bookings', JSON.stringify(updatedBookings));

    // Show Confirmation receipt voucher
    setConfirmedBooking(newBooking);

    // Reset Form
    setName('');
    setEmail('');
    setPhone('');
    setDate('');
    setTime('');
    setGuests(4);
    setSpecialRequests('');
    setValidationError('');
    onClearDraft(); // Clear food draft after booking succeeds
  };

  // Cancel Booking
  const handleCancelBooking = (id: string) => {
    const updated = bookings.filter((b) => b.id !== id);
    setBookings(updated);
    localStorage.setItem('punjabi_virsa_bookings', JSON.stringify(updated));
  };

  // Pre-fill fields for editing
  const handleStartEdit = (b: Booking) => {
    setEditingId(b.id);
    setName(b.name);
    setEmail(b.email);
    setPhone(b.phone);
    setDate(b.date);
    setTime(b.time);
    setGuests(b.guests);
    setSpecialRequests(b.specialRequests || '');
    // Scroll smoothly to form
    const element = document.getElementById('reservation-form-stage');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleUpdateBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingId) return;

    const updated = bookings.map((b) => {
      if (b.id === editingId) {
        return {
          ...b,
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          date,
          time,
          guests,
          specialRequests,
        };
      }
      return b;
    });

    setBookings(updated);
    localStorage.setItem('punjabi_virsa_bookings', JSON.stringify(updated));
    setEditingId(null);
    
    // Reset Form
    setName('');
    setEmail('');
    setPhone('');
    setDate('');
    setTime('');
    setGuests(4);
    setSpecialRequests('');
  };

  return (
    <section id="booking" className="py-24 bg-white border-b border-stone-200/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-widest text-brand-600 uppercase">Seamless Reservations</span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 mt-2 mb-4">
            Book a Table Online
          </h2>
          <p className="text-stone-600 text-sm sm:text-base">
            Skip the waiting queue! Secure your dining table instantly. Select your favorite dishes in advance to let our kitchen prepare for your arrival.
          </p>
        </div>

        {/* Confirmed Booking Voucher Overlay / Success card */}
        {confirmedBooking ? (
          <div className="max-w-xl mx-auto bg-brand-50 border border-amber-200 rounded-3xl overflow-hidden shadow-xl p-8 mb-16 text-center animate-fade-in">
            <div className="bg-emerald-100 text-emerald-800 p-3 rounded-full w-fit mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-emerald-600" />
            </div>
            
            <h3 className="font-serif text-2xl font-bold text-stone-900 mb-2">
              Reservation Confirmed!
            </h3>
            <p className="text-stone-500 text-sm mb-6">
              A dining slot has been locked for you. Present this digital ticket to our staff upon arrival.
            </p>

            {/* Receipt Ticket Details */}
            <div className="bg-white border border-stone-200 rounded-2xl p-6 mb-8 text-left space-y-4 shadow-inner">
              <div className="flex justify-between items-center pb-3 border-b border-stone-100">
                <span className="text-xs text-stone-400 uppercase tracking-widest font-bold">Booking ID</span>
                <span className="font-mono font-bold text-sm text-stone-900">{confirmedBooking.id}</span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-xs text-stone-400 block font-bold uppercase tracking-wider mb-0.5">Guest Name</span>
                  <span className="font-medium text-stone-900">{confirmedBooking.name}</span>
                </div>
                <div>
                  <span className="text-xs text-stone-400 block font-bold uppercase tracking-wider mb-0.5">Assigned Table</span>
                  <span className="font-medium text-stone-950">Table #{confirmedBooking.tableNumber}</span>
                </div>
                <div>
                  <span className="text-xs text-stone-400 block font-bold uppercase tracking-wider mb-0.5">Date</span>
                  <span className="font-medium text-stone-900">{confirmedBooking.date}</span>
                </div>
                <div>
                  <span className="text-xs text-stone-400 block font-bold uppercase tracking-wider mb-0.5">Time Slot</span>
                  <span className="font-medium text-stone-900">{confirmedBooking.time}</span>
                </div>
                <div>
                  <span className="text-xs text-stone-400 block font-bold uppercase tracking-wider mb-0.5">Number of Guests</span>
                  <span className="font-medium text-stone-900">{confirmedBooking.guests} People</span>
                </div>
                <div>
                  <span className="text-xs text-stone-400 block font-bold uppercase tracking-wider mb-0.5">Reservation Status</span>
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full inline-block">
                    CONFIRMED
                  </span>
                </div>
              </div>

              {confirmedBooking.specialRequests && (
                <div className="pt-3 border-t border-stone-100">
                  <span className="text-xs text-stone-400 block font-bold uppercase tracking-wider mb-0.5">Special Requests & Food Order</span>
                  <span className="text-xs text-stone-600 italic block leading-relaxed">
                    {confirmedBooking.specialRequests}
                  </span>
                </div>
              )}
            </div>

            <div className="flex space-x-3 justify-center">
              <button
                onClick={() => setConfirmedBooking(null)}
                className="bg-stone-900 hover:bg-stone-800 text-white font-bold px-6 py-3 rounded-xl text-sm transition-all shadow-md cursor-pointer"
              >
                Make Another Reservation
              </button>
            </div>
          </div>
        ) : null}

        {/* Main Interface Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start" id="reservation-form-stage">
          
          {/* Reservation Booking Form */}
          <div className="lg:col-span-7 bg-brand-50/75 p-6 sm:p-10 rounded-3xl border border-stone-200 shadow-md">
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 mb-2">
              {editingId ? 'Edit Your Reservation' : 'Reservation Form'}
            </h3>
            <p className="text-stone-500 text-xs sm:text-sm mb-8">
              {editingId 
                ? 'Make your corrections below and save your changes.' 
                : 'Fill in your personal information and dining preferences.'}
            </p>

            {validationError && (
              <div className="bg-rose-50 text-rose-800 border border-rose-200 p-4 rounded-2xl mb-6 text-xs font-semibold flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{validationError}</span>
              </div>
            )}

            <form onSubmit={editingId ? handleUpdateBooking : handleBookTable} className="space-y-6">
              
              {/* Form Row: Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="bookName" className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="bookName"
                    required
                    placeholder="e.g. Gurpreet Singh"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-white border border-stone-200 rounded-xl px-4 py-3 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all shadow-sm"
                  />
                </div>
                <div>
                  <label htmlFor="bookEmail" className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="bookEmail"
                    required
                    placeholder="e.g. gurpreet@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-white border border-stone-200 rounded-xl px-4 py-3 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all shadow-sm"
                  />
                </div>
              </div>

              {/* Form Row: Phone & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="bookPhone" className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="bookPhone"
                    required
                    placeholder="e.g. +91 98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-white border border-stone-200 rounded-xl px-4 py-3 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all shadow-sm"
                  />
                </div>
                <div>
                  <label htmlFor="bookDate" className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                    Select Date
                  </label>
                  <div className="relative">
                    <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-400 w-5 h-5 pointer-events-none" />
                    <input
                      type="date"
                      id="bookDate"
                      required
                      min={todayDateStr}
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-white border border-stone-200 rounded-xl px-4 py-3 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all shadow-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Form Row: Time & Guests */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="bookTime" className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                    Preferred Time
                  </label>
                  <div className="relative">
                    <Clock className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-400 w-5 h-5 pointer-events-none" />
                    <select
                      id="bookTime"
                      required
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="w-full bg-white border border-stone-200 rounded-xl px-4 py-3 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all shadow-sm appearance-none"
                    >
                      <option value="">Select a time slot</option>
                      {timeSlots.map((slot, idx) => (
                        <option key={idx} value={slot}>{slot}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label htmlFor="bookGuests" className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                    Guests count
                  </label>
                  <div className="relative">
                    <Users className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-400 w-5 h-5 pointer-events-none" />
                    <select
                      id="bookGuests"
                      value={guests}
                      onChange={(e) => setGuests(Number(e.target.value))}
                      className="w-full bg-white border border-stone-200 rounded-xl px-4 py-3 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all shadow-sm appearance-none"
                    >
                      {Array.from({ length: 12 }).map((_, i) => (
                        <option key={i} value={i + 1}>
                          {i + 1} {i === 0 ? 'Person' : 'People'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Special Requests textarea */}
              <div>
                <label htmlFor="bookNotes" className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                  Special Requests / Dietary Restrictions
                </label>
                <textarea
                  id="bookNotes"
                  rows={3}
                  placeholder="e.g. Wheelchair access, high chair for kids, candlelit table, non-spicy preparation..."
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  className="w-full bg-white border border-stone-200 rounded-xl px-4 py-3 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all shadow-sm"
                />
              </div>

              {/* Submit / Cancel Buttons */}
              <div className="flex space-x-3 pt-2">
                {editingId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingId(null);
                      setName('');
                      setEmail('');
                      setPhone('');
                      setDate('');
                      setTime('');
                      setGuests(4);
                      setSpecialRequests('');
                    }}
                    className="flex-1 border border-stone-300 text-stone-700 font-bold py-3.5 rounded-xl text-sm hover:bg-stone-50 transition-all cursor-pointer"
                  >
                    Cancel Editing
                  </button>
                )}
                <button
                  type="submit"
                  className="flex-1 bg-stone-900 hover:bg-stone-800 text-white font-bold py-3.5 rounded-xl text-sm transition-all shadow-md active:scale-95 flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <Utensils className="w-4.5 h-4.5 text-amber-400" />
                  <span>{editingId ? 'Save Changes' : 'Reserve My Table'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Right Hand Side: Selected Dishes Draft panel & active bookings list */}
          <div className="lg:col-span-5 space-y-8">
            
            {/* 1. Pre-selected Food Orders panel */}
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-sm">
              <h3 className="font-serif text-lg sm:text-xl font-bold text-stone-900 flex items-center space-x-2 pb-4 border-b border-stone-100">
                <Utensils className="w-5 h-5 text-amber-500" />
                <span>Pre-selected Food Order</span>
              </h3>

              {draftItemsDetails.length > 0 ? (
                <div className="mt-4 space-y-4">
                  <div className="space-y-3 max-h-[180px] overflow-y-auto pr-1">
                    {draftItemsDetails.map(({ item, count }) => (
                      <div key={item.id} className="flex justify-between items-center text-sm">
                        <div className="flex items-center space-x-2.5">
                          <span className={`w-2 h-2 rounded-full inline-block ${item.isVeg ? 'bg-emerald-600' : 'bg-rose-600'}`} />
                          <span className="font-medium text-stone-800">{item.name}</span>
                          <span className="text-stone-400 font-mono">x{count}</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <span className="font-semibold text-stone-950">₹{item.price * count}</span>
                          <button
                            onClick={() => onRemoveFromBookingDraft(item)}
                            className="text-stone-400 hover:text-rose-600 p-1 rounded-md cursor-pointer"
                            title="Remove item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 border-t border-stone-100 space-y-2 text-sm">
                    <div className="flex justify-between font-bold text-stone-900 text-base">
                      <span>Estimated Bill (pre-tax)</span>
                      <span>₹{draftTotalPrice}</span>
                    </div>
                    <p className="text-[10px] text-stone-400 italic leading-relaxed">
                      *Pre-selected items are not charged online. You pay at the restaurant after your feast. Prices are subject to local taxes.
                    </p>
                    <button
                      onClick={onClearDraft}
                      className="text-stone-400 hover:text-rose-600 text-xs font-semibold underline mt-2 block cursor-pointer"
                    >
                      Clear Selection Draft
                    </button>
                  </div>
                </div>
              ) : (
                <div className="mt-6 text-center py-6 text-stone-500 text-xs sm:text-sm">
                  <p className="font-semibold text-stone-700 mb-1">Your reservation food draft is empty.</p>
                  <p className="px-4 text-stone-400 leading-relaxed">
                    You can browse our menu above and click the "Add" button to pre-select dishes for your table reservation!
                  </p>
                </div>
              )}
            </div>

            {/* 2. My Bookings Dashboard (active reservations list) */}
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-sm">
              <h3 className="font-serif text-lg sm:text-xl font-bold text-stone-900 flex items-center space-x-2 pb-4 border-b border-stone-100">
                <Clipboard className="w-5 h-5 text-amber-500" />
                <span>My Active Reservations ({bookings.length})</span>
              </h3>

              {bookings.length > 0 ? (
                <div className="mt-4 space-y-4 max-h-[300px] overflow-y-auto pr-1">
                  {bookings.map((booking) => (
                    <div
                      key={booking.id}
                      className="bg-brand-50/50 border border-stone-200 p-4 rounded-xl space-y-3 shadow-inner text-xs sm:text-sm"
                    >
                      <div className="flex justify-between items-center border-b border-stone-100 pb-2">
                        <span className="font-mono font-bold text-stone-800">{booking.id}</span>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleStartEdit(booking)}
                            className="p-1 hover:bg-stone-100 rounded text-stone-600 cursor-pointer"
                            title="Edit reservation Details"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleCancelBooking(booking.id)}
                            className="p-1 hover:bg-rose-50 rounded text-rose-600 cursor-pointer"
                            title="Cancel reservation"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-stone-600">
                        <div>
                          <span className="text-[10px] uppercase text-stone-400 block font-bold">Guest</span>
                          <span className="font-medium text-stone-800">{booking.name}</span>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase text-stone-400 block font-bold">Table</span>
                          <span className="font-semibold text-stone-900">Table #{booking.tableNumber}</span>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase text-stone-400 block font-bold">Date & Time</span>
                          <span className="font-medium text-stone-800">{booking.date} at {booking.time}</span>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase text-stone-400 block font-bold">Guests</span>
                          <span className="font-medium text-stone-800">{booking.guests} People</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-6 text-center py-6 text-stone-400 text-xs sm:text-sm leading-relaxed">
                  No active reservations yet. Secure your table using the booking form.
                </div>
              )}
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
