export interface MenuItem {
  id: string;
  name: string;
  price: number;
  description: string;
  category: 'starters' | 'main_course' | 'breads' | 'rice' | 'desserts' | 'drinks';
  isVeg: boolean;
  isPopular?: boolean;
  spicyLevel?: 0 | 1 | 2 | 3; // 0 = mild, 3 = very spicy
  image: string;
}

export interface Review {
  id: string;
  name: string;
  rating: number;
  text: string;
  date: string;
  verified: boolean;
  reply?: string;
}

export interface Booking {
  id: string;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  specialRequests?: string;
  status: 'pending' | 'confirmed' | 'cancelled';
  tableNumber?: number;
  createdAt: string;
}

export interface SpecialOffer {
  id: string;
  title: string;
  description: string;
  code: string;
  discount: string;
  expiryDate: string;
  image: string;
}
