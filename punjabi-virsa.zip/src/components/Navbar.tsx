import { useState, useEffect } from 'react';
import { Menu, X, Phone, Clock, Star } from 'lucide-react';
import { RESTAURANT_INFO } from '../data';

interface NavbarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export default function Navbar({ activeSection, setActiveSection }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const navLinks = [
    { name: 'Home', id: 'home' },
    { name: 'About', id: 'about' },
    { name: 'Our Menu', id: 'menu' },
    { name: 'Special Offers', id: 'offers' },
    { name: 'Gallery', id: 'gallery' },
    { name: 'Reviews', id: 'reviews' },
    { name: 'Book a Table', id: 'booking' },
    { name: 'Contact Us', id: 'contact' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (id: string) => {
    setIsOpen(false);
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Top Banner (Contact & Hours Info) */}
      <div className="hidden sm:flex bg-brand-800 text-brand-100 text-xs py-2 px-4 justify-between items-center border-b border-brand-700">
        <div className="flex items-center space-x-6">
          <span className="flex items-center space-x-1.5">
            <Phone className="w-3.5 h-3.5 text-brand-500" />
            <a href={`tel:${RESTAURANT_INFO.phone}`} className="hover:text-brand-500 transition-colors">
              {RESTAURANT_INFO.phone}
            </a>
          </span>
          <span className="flex items-center space-x-1.5">
            <Clock className="w-3.5 h-3.5 text-brand-500" />
            <span>Open Daily: {RESTAURANT_INFO.openingHours.split('(')[0].trim()}</span>
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="flex items-center space-x-1 text-amber-400 bg-brand-700/60 px-2 py-0.5 rounded-full font-medium">
            <Star className="w-3.5 h-3.5 fill-current" />
            <span>{RESTAURANT_INFO.rating.toFixed(1)}/5</span>
          </span>
          <span className="text-brand-200">({RESTAURANT_INFO.reviewCount.toLocaleString()}+ reviews)</span>
        </div>
      </div>

      {/* Main Sticky Navbar */}
      <nav
        id="navbar"
        className={`sticky top-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-stone-900/95 backdrop-blur-md shadow-lg py-3'
            : 'bg-stone-950 py-4 border-b border-stone-800'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Brand Logo */}
            <div className="flex-shrink-0 cursor-pointer" onClick={() => handleNavClick('home')}>
              <div className="flex flex-col">
                <span className="font-serif font-bold text-2xl tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-200 to-amber-500">
                  {RESTAURANT_INFO.name}
                </span>
                <span className="text-[9px] uppercase tracking-widest text-amber-500/80 -mt-0.5 font-medium">
                  Authentic North Indian Cuisine
                </span>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <div className="hidden lg:flex items-center space-x-1">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`px-3.5 py-2 text-sm font-medium rounded-md transition-all duration-200 cursor-pointer ${
                    activeSection === link.id
                      ? 'text-amber-400 bg-stone-800/80 border-b-2 border-amber-500 rounded-b-none'
                      : 'text-stone-300 hover:text-amber-400 hover:bg-stone-900/40'
                  }`}
                >
                  {link.name}
                </button>
              ))}
            </div>

            {/* Book a Table Action Button */}
            <div className="hidden sm:block">
              <button
                onClick={() => handleNavClick('booking')}
                className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-stone-950 px-5 py-2 rounded-full text-sm font-semibold shadow-md shadow-amber-500/10 hover:shadow-amber-500/20 active:scale-95 transition-all cursor-pointer"
              >
                Book a Table
              </button>
            </div>

            {/* Mobile Hamburger Button */}
            <div className="lg:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="text-stone-300 hover:text-amber-400 p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {isOpen && (
          <div className="lg:hidden bg-stone-950 border-t border-stone-800">
            <div className="px-2 pt-2 pb-4 space-y-1 sm:px-3">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`block w-full text-left px-4 py-3 text-base font-medium rounded-md transition-colors ${
                    activeSection === link.id
                      ? 'text-amber-400 bg-stone-900 border-l-4 border-amber-500'
                      : 'text-stone-300 hover:text-amber-400 hover:bg-stone-900/60'
                  }`}
                >
                  {link.name}
                </button>
              ))}
              <div className="pt-4 px-4 sm:hidden">
                <button
                  onClick={() => handleNavClick('booking')}
                  className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 py-3 rounded-xl text-center font-semibold text-sm shadow-md"
                >
                  Book a Table
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
