import { MenuItem, Review, SpecialOffer } from './types';

export const RESTAURANT_INFO = {
  name: "PUNJABI VIRSA",
  tagline: "Authentic Punjabi Flavors, Served with Love.",
  description: "Punjabi Virsa is a family-friendly restaurant serving authentic North Indian and Punjabi cuisine. Known for rich curries, fresh tandoori breads, and traditional recipes, it offers a comfortable dining experience for families, friends, and food lovers.",
  cuisine: ["Punjabi", "North Indian", "Tandoori", "Vegetarian & Non-Vegetarian"],
  priceRange: "₹200–₹1000 per person",
  rating: 4.0,
  reviewCount: 1800,
  address: "CH Harpal Chandela Rd, Shyam Nagar, Vishnu Garden, New Delhi, Delhi 110018",
  phone: "+91 88003 66006",
  email: "info@punjabivirsa.com",
  openingHours: "12:00 PM – 12:00 AM (Monday – Sunday)",
  aboutText: "Since opening our doors, Punjabi Virsa has been dedicated to bringing authentic Punjabi cuisine to every table. Using fresh ingredients, traditional spices, and time-tested recipes, we create meals that remind guests of home-cooked food."
};

export const MENU_ITEMS: MenuItem[] = [
  // --- STARTERS ---
  {
    id: "s1",
    name: "Paneer Tikka",
    price: 320,
    description: "Cubes of fresh cottage cheese marinated in spiced yogurt and grilled to golden perfection in our traditional clay oven.",
    category: "starters",
    isVeg: true,
    isPopular: true,
    spicyLevel: 2,
    image: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "s2",
    name: "Hara Bhara Kebab",
    price: 280,
    description: "Crispy and nutritious shallow-fried patties made with spinach, green peas, potatoes, and dynamic Punjabi spices.",
    category: "starters",
    isVeg: true,
    spicyLevel: 1,
    image: "https://images.unsplash.com/photo-1601050690597-df056fb4ce78?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "s3",
    name: "Chicken Tikka",
    price: 360,
    description: "Tender, boneless chicken chunks marinated in mustard oil, yogurt, and hot tandoori spices, flame-broiled in the tandoor.",
    category: "starters",
    isVeg: false,
    isPopular: true,
    spicyLevel: 3,
    image: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "s4",
    name: "Tandoori Chicken",
    price: 480,
    description: "Half or full bird on the bone, dry-rubbed in a secret Punjabi spice blend, steeped in yogurt, and charred beautifully.",
    category: "starters",
    isVeg: false,
    spicyLevel: 2,
    image: "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=600&q=80"
  },

  // --- MAIN COURSE ---
  {
    id: "m1",
    name: "Butter Chicken",
    price: 420,
    description: "Our signature dish. Tandoor-grilled chicken smothered in a silky, rich tomato-cream sauce with a hint of dried fenugreek.",
    category: "main_course",
    isVeg: false,
    isPopular: true,
    spicyLevel: 1,
    image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "m2",
    name: "Dal Makhani",
    price: 280,
    description: "Whole black lentils and red kidney beans slow-cooked overnight on charcoal with butter, cream, and fresh tomatoes.",
    category: "main_course",
    isVeg: true,
    isPopular: true,
    spicyLevel: 1,
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "m3",
    name: "Shahi Paneer",
    price: 300,
    description: "Delicate cottage cheese blocks bathed in a royal, creamy cashew nut and tomato gravy, garnished with rich saffron.",
    category: "main_course",
    isVeg: true,
    spicyLevel: 1,
    image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "m4",
    name: "Kadhai Chicken",
    price: 390,
    description: "Juicy chicken stir-fried with bell peppers, fresh onions, tomatoes, and coarsely crushed coriander seeds in an iron kadhai.",
    category: "main_course",
    isVeg: false,
    spicyLevel: 3,
    image: "https://images.unsplash.com/photo-1624462966581-bc6d768cbce5?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "m5",
    name: "Chole Bhature",
    price: 220,
    description: "Tangy, spicy chickpea curry (Amritsari style) served alongside two golden, fluffy, deep-fried puffed leavened breads.",
    category: "main_course",
    isVeg: true,
    isPopular: true,
    spicyLevel: 2,
    image: "https://images.unsplash.com/photo-1626132647523-66f5bf380027?auto=format&fit=crop&w=600&q=80"
  },

  // --- BREADS ---
  {
    id: "b1",
    name: "Butter Naan",
    price: 60,
    description: "Leavened fine flour flatbread baked fresh inside the clay tandoor and generously brushed with melted salted butter.",
    category: "breads",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1601050690597-df056fb4ce78?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "b2",
    name: "Garlic Naan",
    price: 80,
    description: "Soft flatbread infused with roasted minced garlic, fresh cilantro, and finished with warm butter.",
    category: "breads",
    isVeg: true,
    isPopular: true,
    image: "https://images.unsplash.com/photo-1601050690597-df056fb4ce78?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "b3",
    name: "Tandoori Roti",
    price: 30,
    description: "Healthy and simple whole-wheat flatbread cooked directly on the clay walls of our blazing hot tandoor.",
    category: "breads",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "b4",
    name: "Lachha Paratha",
    price: 90,
    description: "Multi-layered, flaky, golden brown whole wheat bread with folds of butter in every bite.",
    category: "breads",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=600&q=80"
  },

  // --- RICE ---
  {
    id: "r1",
    name: "Veg Biryani",
    price: 260,
    description: "Long-grain basmati rice cooked on slow dum heat with assorted vegetables, fresh mint, fried onions, and royal spices.",
    category: "rice",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "r2",
    name: "Chicken Biryani",
    price: 360,
    description: "Fragrant layers of premium basmati rice and richly marinated bone-in chicken dum-cooked in sealed earthen handi.",
    category: "rice",
    isVeg: false,
    isPopular: true,
    image: "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "r3",
    name: "Jeera Rice",
    price: 180,
    description: "Fluffy basmati rice tempered with crackling cumin seeds and fresh ghee.",
    category: "rice",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1541658016709-82535e94bc69?auto=format&fit=crop&w=600&q=80"
  },

  // --- DESSERTS ---
  {
    id: "d1",
    name: "Gulab Jamun",
    price: 120,
    description: "Golden-brown soft milk dumplings fried and soaked in a warm cardamom and rose-water infused sugar syrup. Served warm.",
    category: "desserts",
    isVeg: true,
    isPopular: true,
    image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "d2",
    name: "Rasmalai",
    price: 140,
    description: "Chilled spongy cottage cheese patties steeped in thick, saffron-flavored milk, topped with pistachios and almonds.",
    category: "desserts",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "d3",
    name: "Kulfi",
    price: 130,
    description: "Traditional dense, slow-reduced Indian ice cream enriched with green cardamom, saffron, and roasted nuts.",
    category: "desserts",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80"
  },

  // --- DRINKS ---
  {
    id: "dr1",
    name: "Sweet Lassi",
    price: 120,
    description: "Thick, creamy yogurt beverage blended sweet with a splash of rose water and topped with a luscious dollop of malai.",
    category: "drinks",
    isVeg: true,
    isPopular: true,
    image: "https://images.unsplash.com/photo-1541658016709-82535e94bc69?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "dr2",
    name: "Masala Chaas",
    price: 90,
    description: "A refreshing, salted churned buttermilk infused with roasted cumin, mint, green chilies, and black salt.",
    category: "drinks",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1541658016709-82535e94bc69?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "dr3",
    name: "Fresh Lime Soda",
    price: 100,
    description: "Bubbly and crisp soda with hand-squeezed lime juice, available in Sweet, Salted, or Mixed flavor profiles.",
    category: "drinks",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1541658016709-82535e94bc69?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "dr4",
    name: "Soft Drinks",
    price: 60,
    description: "A choice of chilled canned soft beverages to complement your rich Punjabi feast.",
    category: "drinks",
    isVeg: true,
    image: "https://images.unsplash.com/photo-1541658016709-82535e94bc69?auto=format&fit=crop&w=600&q=80"
  }
];

export const SPECIAL_OFFERS: SpecialOffer[] = [
  {
    id: "o1",
    title: "Amritsari Kulcha & Lassi Feast",
    description: "Authentic tandoori stuffed Amritsari Kulcha served with tangy chole, spicy pickle, onion salad, and a full glass of Sweet Lassi.",
    code: "AMRITSAR15",
    discount: "15% OFF",
    expiryDate: "Valid on weekdays",
    image: "https://images.unsplash.com/photo-1626132647523-66f5bf380027?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "o2",
    title: "First Online Takeaway Order",
    description: "Experience the convenience of authentic Punjabi flavours right at your doorstep. Get a delightful discount on your first takeaway order.",
    code: "WELCOMEVIRSA",
    discount: "15% OFF",
    expiryDate: "New customers only",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "o3",
    title: "Weekend Family Banquet",
    description: "Order any two premium Punjabi Main Courses and get a free starter of your choice (Paneer Tikka or Crispy Hara Bhara Kebab) for the table.",
    code: "FAMILYFEAST",
    discount: "FREE STARTER",
    expiryDate: "Saturdays & Sundays",
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80"
  }
];

export const REVIEWS: Review[] = [
  {
    id: "rev1",
    name: "Amanpreet Singh",
    rating: 5,
    text: "Amazing Butter Chicken and Garlic Naan. The flavors are absolutely spot on, reminding me of the dhabas along the GT Road in Punjab. Great family atmosphere!",
    date: "2026-06-15",
    verified: true,
    reply: "Thank you so much, Amanpreet! We take great pride in our tandoor recipes and are thrilled you enjoyed the authentic taste."
  },
  {
    id: "rev2",
    name: "Riya Sharma",
    rating: 4,
    text: "Good food, generous portions, and friendly staff. The Chole Bhature are non-greasy yet incredibly fluffy, and the sweet lassi is huge! Recommend reserving a table on weekends.",
    date: "2026-06-20",
    verified: true,
    reply: "Lovely feedback, Riya! We are happy you enjoyed the Chole Bhature and the Lassi. Hope to host you again soon."
  },
  {
    id: "rev3",
    name: "Michael Vance",
    rating: 5,
    text: "One of the best Punjabi restaurants in the area. The Dal Makhani is rich, creamy, and slow-cooked to absolute perfection. Extremely friendly and fast service.",
    date: "2026-06-24",
    verified: true,
    reply: "Thank you, Michael! Our Dal Makhani is simmered for over 12 hours, so hearing this makes our day!"
  }
];

export const WHY_CHOOSE_US = [
  {
    title: "Fresh Ingredients",
    description: "We pick premium, garden-fresh vegetables and top-grade farm meats daily to preserve pure flavors.",
    icon: "Leaf"
  },
  {
    title: "Authentic Recipes",
    description: "Our dishes are made using traditional spice blends passed down through generations of Punjabi chefs.",
    icon: "Flame"
  },
  {
    title: "Family Dining",
    description: "A comfortable, spacious, and warm ambience specifically designed for families to bond over food.",
    icon: "Users"
  },
  {
    title: "Fast & Friendly Service",
    description: "Our dedicated team ensures your freshly baked naan and sizzling curries arrive hot and promptly.",
    icon: "Zap"
  },
  {
    title: "Affordable Prices",
    description: "Premium ingredients and high culinary standards, offered at pocket-friendly and honest pricing.",
    icon: "CreditCard"
  },
  {
    title: "Hygienic Kitchen",
    description: "A spotless, modern kitchen maintaining the highest industry standards of sanitization and safety.",
    icon: "ShieldCheck"
  },
  {
    title: "Takeaway Available",
    description: "Craving dhabha food at home? Grab freshly packed takeaways with secure, leak-proof food containers.",
    icon: "ShoppingBag"
  }
];

export const GALLERY_IMAGES = [
  {
    url: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=800&q=80",
    caption: "Marinated Tandoori Paneer Tikka"
  },
  {
    url: "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=800&q=80",
    caption: "Traditional Charred Tandoori Chicken"
  },
  {
    url: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=80",
    caption: "Aromatic Butter Chicken Curry"
  },
  {
    url: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
    caption: "Rich Overnight Dal Makhani"
  },
  {
    url: "https://images.unsplash.com/photo-1626132647523-66f5bf380027?auto=format&fit=crop&w=800&q=80",
    caption: "Fluffy Chole Bhature Platter"
  },
  {
    url: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
    caption: "Basmati Dum Veg Biryani"
  }
];
