import React, { useState, useEffect } from 'react';
import { Star, MessageSquare, BadgeCheck, Check, Sparkles } from 'lucide-react';
import { Review } from '../types';
import { REVIEWS } from '../data';

export default function Reviews() {
  const [reviewsList, setReviewsList] = useState<Review[]>([]);
  const [newReviewName, setNewReviewName] = useState('');
  const [newReviewText, setNewReviewText] = useState('');
  const [newReviewRating, setNewReviewRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [validationError, setValidationError] = useState('');

  // Load reviews from localStorage on mount, fall back to initial static data
  useEffect(() => {
    const stored = localStorage.getItem('punjabi_virsa_reviews');
    if (stored) {
      try {
        setReviewsList(JSON.parse(stored));
      } catch (err) {
        setReviewsList(REVIEWS);
      }
    } else {
      setReviewsList(REVIEWS);
    }
  }, []);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation
    if (!newReviewName.trim() || !newReviewText.trim()) {
      setValidationError('Please fill in both your name and review details.');
      return;
    }
    if (newReviewText.trim().length < 10) {
      setValidationError('Your review must be at least 10 characters long.');
      return;
    }

    const createdReview: Review = {
      id: `custom-rev-${Date.now()}`,
      name: newReviewName.trim(),
      rating: newReviewRating,
      text: newReviewText.trim(),
      date: new Date().toISOString().split('T')[0],
      verified: false, // Custom reviews don't start verified
    };

    const updated = [createdReview, ...reviewsList];
    setReviewsList(updated);
    localStorage.setItem('punjabi_virsa_reviews', JSON.stringify(updated));

    // Reset Form
    setNewReviewName('');
    setNewReviewText('');
    setNewReviewRating(5);
    setValidationError('');
    setSubmitSuccess(true);

    // Clear success message after 5 seconds
    setTimeout(() => {
      setSubmitSuccess(false);
    }, 5000);
  };

  return (
    <section id="reviews" className="py-24 bg-brand-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-widest text-brand-600 uppercase">Guest Experiences</span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 mt-2 mb-4">
            What Our Customers Say
          </h2>
          <p className="text-stone-600 text-sm sm:text-base">
            Honest feedback from food lovers who dined with us. We read every review to keep improving our recipes and service!
          </p>
        </div>

        {/* Main Grid: Reviews List & Review Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Reviews List */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 flex items-center space-x-2 mb-2">
              <MessageSquare className="w-5.5 h-5.5 text-amber-500" />
              <span>Recent Guest Reviews ({reviewsList.length})</span>
            </h3>

            <div className="space-y-6 max-h-[600px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-amber-500 scrollbar-track-stone-100">
              {reviewsList.map((rev) => (
                <div
                  key={rev.id}
                  className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200/60 shadow-sm space-y-4"
                >
                  {/* Review Header */}
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-serif font-bold text-stone-900 text-base sm:text-lg">
                          {rev.name}
                        </span>
                        {rev.verified && (
                          <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center space-x-0.5" title="Verified Customer Review">
                            <BadgeCheck className="w-3.5 h-3.5 text-emerald-600 fill-emerald-50" />
                            <span className="hidden sm:inline">Verified Dine</span>
                          </span>
                        )}
                      </div>
                      <span className="text-stone-400 text-xs">{rev.date}</span>
                    </div>

                    {/* Stars */}
                    <div className="flex items-center text-amber-400">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < rev.rating ? 'fill-current' : 'text-stone-200'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Review Body */}
                  <p className="text-stone-700 text-xs sm:text-sm leading-relaxed italic">
                    "{rev.text}"
                  </p>

                  {/* Restaurant Owner Response */}
                  {rev.reply && (
                    <div className="bg-brand-50 p-4 rounded-xl border border-brand-100/80 mt-4 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-brand-600 tracking-wider">
                        Response from Owner
                      </span>
                      <p className="text-stone-600 text-xs leading-relaxed font-sans">
                        {rev.reply}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Leave a Review Form */}
          <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/60 shadow-md">
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 mb-2">
              Share Your Experience
            </h3>
            <p className="text-stone-500 text-xs sm:text-sm mb-6">
              Dined with us recently? We'd love to hear your honest feedback on our service and traditional flavors.
            </p>

            {submitSuccess && (
              <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 p-4 rounded-2xl mb-6 flex items-start space-x-3 text-xs sm:text-sm">
                <div className="bg-emerald-100 text-emerald-700 p-1 rounded-full shrink-0">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold block">Review Submitted!</span>
                  <span>Thank you for sharing your feedback. Your review is now visible in the list below.</span>
                </div>
              </div>
            )}

            {validationError && (
              <div className="bg-rose-50 text-rose-800 border border-rose-200 p-4 rounded-2xl mb-6 text-xs font-semibold">
                {validationError}
              </div>
            )}

            <form onSubmit={handleSubmitReview} className="space-y-4">
              {/* Star Rating Select */}
              <div>
                <label className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                  Your Rating
                </label>
                <div className="flex items-center space-x-2">
                  {Array.from({ length: 5 }).map((_, i) => {
                    const ratingValue = i + 1;
                    return (
                      <button
                        type="button"
                        key={i}
                        onClick={() => setNewReviewRating(ratingValue)}
                        onMouseEnter={() => setHoverRating(ratingValue)}
                        onMouseLeave={() => setHoverRating(null)}
                        className="p-1 focus:outline-none cursor-pointer transition-transform duration-100 active:scale-90"
                      >
                        <Star
                          className={`w-8 h-8 ${
                            ratingValue <= (hoverRating ?? newReviewRating)
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-stone-200'
                          }`}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Name Input */}
              <div>
                <label htmlFor="revName" className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  id="revName"
                  placeholder="e.g. Jasprit Kaur"
                  value={newReviewName}
                  onChange={(e) => setNewReviewName(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent focus:bg-white transition-all shadow-sm"
                />
              </div>

              {/* Review Text Area */}
              <div>
                <label htmlFor="revText" className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                  Detailed Review
                </label>
                <textarea
                  id="revText"
                  rows={4}
                  placeholder="Tell us about the food, staff, atmosphere, and which dishes you ordered..."
                  value={newReviewText}
                  onChange={(e) => setNewReviewText(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent focus:bg-white transition-all shadow-sm"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-stone-900 hover:bg-stone-800 text-white font-bold py-3.5 rounded-xl text-sm transition-all shadow-md active:scale-95 flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Sparkles className="w-4.5 h-4.5 text-amber-400" />
                <span>Publish Review</span>
              </button>
            </form>
          </div>

        </div>
      </div>
    </section>
  );
}
