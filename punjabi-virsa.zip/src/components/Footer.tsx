import { Heart, Star } from 'lucide-react';
import { RESTAURANT_INFO } from '../data';

interface FooterProps {
  onNavClick: (sectionId: string) => void;
}

export default function Footer({ onNavClick }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-stone-950 text-stone-300 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Column 1: Brand Info */}
          <div className="space-y-4">
            <div className="flex flex-col cursor-pointer" onClick={() => onNavClick('home')}>
              <span className="font-serif font-bold text-2xl tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-200 to-amber-500">
                {RESTAURANT_INFO.name}
              </span>
              <span className="text-[10px] uppercase tracking-widest text-amber-500/80 -mt-0.5 font-medium">
                Authentic North Indian Cuisine
              </span>
            </div>
            <p className="text-stone-400 text-xs sm:text-sm leading-relaxed font-sans">
              Experience the heritage of rich clay-oven delicacies, slow-simmered dals, and golden tandoori breads served directly in a warm, family environment.
            </p>
            <div className="flex items-center space-x-1.5 text-amber-400 bg-stone-900/60 w-fit px-3 py-1 rounded-full text-xs font-semibold">
              <Star className="w-3.5 h-3.5 fill-current" />
              <span>{RESTAURANT_INFO.rating.toFixed(1)} Rating (1,800+ reviews)</span>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="font-serif text-white font-bold text-base mb-4 uppercase tracking-wider border-b border-stone-800 pb-2">
              Explore Virsa
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavClick('home')}
                  className="text-stone-400 hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Home / Welcome
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavClick('about')}
                  className="text-stone-400 hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Our Heritage & Why Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavClick('menu')}
                  className="text-stone-400 hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Digital Food Menu
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavClick('offers')}
                  className="text-stone-400 hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Special Offers & Combos
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavClick('booking')}
                  className="text-stone-400 hover:text-amber-400 transition-colors cursor-pointer text-amber-400 font-semibold"
                >
                  Reserve a Table Online
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Popular Cuisine Categories */}
          <div>
            <h4 className="font-serif text-white font-bold text-base mb-4 uppercase tracking-wider border-b border-stone-800 pb-2">
              Culinary Specialties
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-stone-400">
              <li className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                <span>Smoky Clay-Oven Kebabs</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                <span>Rich Butter Chicken & Paneer</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                <span>Authentic Overnight-Cooked Dals</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                <span>Fluffy Stuffed Naans & Rotis</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                <span>Chilled Sweet Lassi & Kulfis</span>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact details */}
          <div>
            <h4 className="font-serif text-white font-bold text-base mb-4 uppercase tracking-wider border-b border-stone-800 pb-2">
              Find Our Store
            </h4>
            <p className="text-stone-400 text-xs sm:text-sm leading-relaxed mb-4">
              {RESTAURANT_INFO.address}
            </p>
            <div className="space-y-1 text-xs sm:text-sm">
              <p>
                <span className="text-stone-500">Phone: </span>
                <a href={`tel:${RESTAURANT_INFO.phone}`} className="text-amber-400 hover:underline">
                  {RESTAURANT_INFO.phone}
                </a>
              </p>
              <p>
                <span className="text-stone-500">Email: </span>
                <a href={`mailto:${RESTAURANT_INFO.email}`} className="hover:text-white transition-colors">
                  {RESTAURANT_INFO.email}
                </a>
              </p>
              <p className="pt-2">
                <span className="text-stone-500 block">Opening Hours:</span>
                <span className="text-stone-300 font-semibold">{RESTAURANT_INFO.openingHours}</span>
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Attribution */}
        <div className="pt-8 border-t border-stone-800 flex flex-col sm:flex-row justify-between items-center text-xs text-stone-500 space-y-4 sm:space-y-0">
          <p>© {currentYear} Punjabi Virsa. All rights reserved. Shyam Nagar, New Delhi.</p>
          <p className="flex items-center space-x-1">
            <span>Crafted with</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-current" />
            <span>for authentic Punjabi hospitality.</span>
          </p>
        </div>

      </div>
    </footer>
  );
}
