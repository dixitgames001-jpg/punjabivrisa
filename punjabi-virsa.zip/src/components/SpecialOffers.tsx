import { useState } from 'react';
import { Tag, Copy, Check, Calendar } from 'lucide-react';
import { SPECIAL_OFFERS } from '../data';

export default function SpecialOffers() {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code).then(() => {
      setCopiedCode(code);
      setTimeout(() => setCopiedCode(null), 2000);
    });
  };

  return (
    <section id="offers" className="py-24 bg-brand-50/50 border-t border-b border-stone-200/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-widest text-brand-600 uppercase">Limited Time Promos</span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 mt-2 mb-4">
            Special Offers & Combos
          </h2>
          <p className="text-stone-600 text-sm sm:text-base">
            Claim these authentic deals to feast with your family, friends, or enjoy hot takeaway delicacies at exclusive prices.
          </p>
        </div>

        {/* Promo Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SPECIAL_OFFERS.map((offer) => (
            <div
              key={offer.id}
              className="bg-white rounded-3xl overflow-hidden border border-stone-200/60 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Offer Header with Discount badge overlay */}
                <div className="relative h-48 bg-stone-100">
                  <img
                    src={offer.image}
                    alt={offer.title}
                    className="w-full h-full object-cover filter brightness-[0.85]"
                  />
                  <div className="absolute top-4 left-4 bg-amber-500 text-stone-950 px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center space-x-1 shadow-sm">
                    <Tag className="w-3.5 h-3.5 fill-current" />
                    <span>{offer.discount}</span>
                  </div>
                </div>

                {/* Offer details */}
                <div className="p-6 sm:p-8">
                  <h3 className="font-serif font-bold text-stone-900 text-xl mb-3">
                    {offer.title}
                  </h3>
                  <p className="text-stone-600 text-xs sm:text-sm leading-relaxed mb-6">
                    {offer.description}
                  </p>
                </div>
              </div>

              {/* Promo Code Copy Bar */}
              <div className="p-6 sm:p-8 bg-brand-50/60 border-t border-stone-100/80 rounded-b-3xl">
                {/* Expiry details */}
                <div className="flex items-center space-x-1.5 text-stone-500 text-xs mb-4">
                  <Calendar className="w-3.5 h-3.5" />
                  <span className="font-medium">{offer.expiryDate}</span>
                </div>

                {/* Code Copy button */}
                <div className="flex items-center justify-between bg-white border border-stone-200 rounded-xl p-2.5">
                  <div className="pl-2">
                    <span className="text-[10px] uppercase text-stone-400 block font-bold leading-none mb-0.5">Promo Code</span>
                    <span className="font-mono font-bold text-sm text-stone-900 leading-none">{offer.code}</span>
                  </div>
                  
                  <button
                    onClick={() => handleCopyCode(offer.code)}
                    className={`flex items-center space-x-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      copiedCode === offer.code
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-stone-900 text-white hover:bg-stone-800'
                    }`}
                  >
                    {copiedCode === offer.code ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
