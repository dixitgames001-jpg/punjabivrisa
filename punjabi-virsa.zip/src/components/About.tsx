import React from 'react';
import { motion } from 'motion/react';
import { Leaf, Flame, Users, Zap, CreditCard, ShieldCheck, ShoppingBag, UtensilsCrossed } from 'lucide-react';
import { RESTAURANT_INFO, WHY_CHOOSE_US } from '../data';

const iconMap: { [key: string]: React.ComponentType<any> } = {
  Leaf: Leaf,
  Flame: Flame,
  Users: Users,
  Zap: Zap,
  CreditCard: CreditCard,
  ShieldCheck: ShieldCheck,
  ShoppingBag: ShoppingBag,
};

export default function About() {
  return (
    <section id="about" className="py-24 bg-brand-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Intro Grid: Brand Story */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-24">
          <div className="lg:col-span-5 relative">
            <div className="absolute -top-4 -left-4 w-20 h-20 bg-amber-500/10 rounded-full blur-xl" />
            <span className="text-xs font-bold tracking-widest text-brand-600 uppercase">Our Story</span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 mt-2 mb-6">
              Dedicated to Authentic Heritage
            </h2>
            <div className="h-1 w-20 bg-amber-500 rounded-full mb-8" />
            <blockquote className="border-l-4 border-amber-500 pl-6 text-stone-700 italic text-lg sm:text-xl font-medium leading-relaxed mb-6">
              "{RESTAURANT_INFO.aboutText}"
            </blockquote>
            <p className="text-stone-600 leading-relaxed font-sans text-sm sm:text-base">
              At {RESTAURANT_INFO.name}, we believe dining is not just about eating; it is an experience of culture, warmth, and family hospitality. Our team carefully toasts, grinds, and blends spices in-house to capture the original essence of traditional Punjabi kitchens.
            </p>
          </div>

          <div className="lg:col-span-7 grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="overflow-hidden rounded-2xl shadow-md h-48 sm:h-64 relative group">
                <img
                  src="https://images.unsplash.com/photo-1541658016709-82535e94bc69?auto=format&fit=crop&w=600&q=80"
                  alt="Traditional Lassi being poured"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-stone-900/10 group-hover:bg-transparent transition-all" />
              </div>
              <div className="bg-brand-800 text-brand-100 p-6 sm:p-8 rounded-2xl shadow-lg border border-brand-700 flex flex-col justify-center">
                <span className="text-4xl sm:text-5xl font-serif font-bold text-amber-400">4.0</span>
                <span className="text-xs uppercase tracking-wider text-brand-300 font-semibold mt-1">Google Rating</span>
                <span className="text-xs text-brand-200 mt-2">Backed by 1,800+ authentic reviews.</span>
              </div>
            </div>
            <div className="space-y-4 pt-8">
              <div className="bg-amber-500 text-stone-950 p-6 sm:p-8 rounded-2xl shadow-lg flex flex-col justify-center">
                <UtensilsCrossed className="w-8 h-8 text-stone-950 mb-3" />
                <span className="text-lg sm:text-xl font-serif font-bold">100% Traditional</span>
                <span className="text-xs sm:text-sm font-medium opacity-90 mt-1">Tandoori clay-oven baking and hand-crafted masalas.</span>
              </div>
              <div className="overflow-hidden rounded-2xl shadow-md h-48 sm:h-64 relative group">
                <img
                  src="https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80"
                  alt="Sizzling hot butter chicken curry"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-stone-900/10 group-hover:bg-transparent transition-all" />
              </div>
            </div>
          </div>
        </div>

        {/* Why Choose Us - Bento Grid / Cards */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-widest text-brand-600 uppercase">The Virsa Standard</span>
          <h3 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 mt-2 mb-4">
            Why Food Lovers Choose Us
          </h3>
          <p className="text-stone-600 text-sm sm:text-base">
            We hold ourselves to absolute quality and hospitality. Here is what makes every dining experience at Punjabi Virsa unforgettable.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {WHY_CHOOSE_US.map((item, index) => {
            const IconComponent = iconMap[item.icon] || Leaf;
            return (
              <motion.div
                key={index}
                whileHover={{ y: -4 }}
                transition={{ duration: 0.2 }}
                className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200/60 shadow-sm hover:shadow-md transition-all flex flex-col space-y-4"
              >
                <div className="bg-amber-500/10 text-brand-600 p-3 rounded-xl w-fit">
                  <IconComponent className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-stone-950 text-base sm:text-lg mb-2">{item.title}</h4>
                  <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">{item.description}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
